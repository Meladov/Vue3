<template>
<div class="wrapper">
  <headerOne/>
  <div class="wrapper-content">
    <div class="container">
      <h1>hello</h1>
      <p>hello 2</p>
    </div>
  </div>
  <footerOne />
</div>
</template>

<script>
import HeaderOne from '@/components/HeaderOne'
import FooterOne from '@/components/FooterOne'
export default {
  components: {
    HeaderOne,
    FooterOne
  }
}
</script>