<template>
    <header class="navbar">
        <div class="container">
            <div class="navbar-content">
                <a href="/" class="navbar-logo">logo</a>
                <ul class="navbar-list"></ul>
            </div>
        </div>
    </header>
</template>